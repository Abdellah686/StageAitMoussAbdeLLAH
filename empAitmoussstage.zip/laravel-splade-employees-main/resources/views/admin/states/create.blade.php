<x-admin-layout>
    <div class="flex justify-between">
        <h1 class="text-2xl font-semibold p-4">Create State</h1>
    </div>
    <x-splade-form :for="$form" />
</x-admin-layout>
