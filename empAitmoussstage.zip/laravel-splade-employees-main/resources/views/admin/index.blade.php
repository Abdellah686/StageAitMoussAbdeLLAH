<x-admin-layout>
    <h1>Welcome to admin</h1>
</x-admin-layout>
