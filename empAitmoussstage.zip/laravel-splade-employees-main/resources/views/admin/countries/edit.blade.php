<x-admin-layout>
    <h1 class="text-2xl font-semibold p-4">Edit Country</h1>
    <x-splade-form :for="$form" />
</x-admin-layout>
